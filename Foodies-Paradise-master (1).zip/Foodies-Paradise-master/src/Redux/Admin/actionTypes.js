export const postreq="postreq"
export const postsucc="postsucc"
export const postfail="postfail"

// delete
export const deletereq="deletereq"
export const deletesucc="deletesucc"
export const deletefail="deletefail"

// update
export const updatereq="updatereq"
export const updatesucc="updatesucc"
export const updatefail="updatefail"
